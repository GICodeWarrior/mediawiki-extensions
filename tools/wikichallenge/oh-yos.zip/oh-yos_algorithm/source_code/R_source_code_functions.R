#R source code functions


getMatrix <- function(password){

	library(RODBC)
	connMySQL<-odbcConnect("connMySQL","root",password)

	#get regdates data
	Rquery<-paste("select user_id,period_id from period,regdates where start_date <=registration_date and registration_date<=end_date")
	regclass<-sqlQuery(connMySQL,query=Rquery)

	#get training data
	Rquery<-paste("select distinct user_id from training")
	editors<-sqlQuery(connMySQL,query=Rquery)

	Rquery<-paste("select user_id,article_id,namespace,period_id,delta,cur_size,reverted,reverted_user_id,category,redirect,related_page,title_length,comment_length from period,variables where start_date <=timestamp and timestamp<=end_date and user_id=",editors[,1],sep="")
	vars<-lapply(Rquery,function(x){sqlQuery(connMySQL,query=x)})

	trainlists<-lapply(vars,function(x){ComputeVariables(x,regclass,target=23)})
	testlists<-lapply(vars,function(x){ComputeVariables(x,regclass,target=24)})

	invec<-sapply(trainlists,nonPredict)
	trainlists<-trainlists[which(invec==1)]
	trainMatrix<-do.call("rbind",trainlists)
	testMatrix<-do.call("rbind",testlists)

	result<-list(trainMatrix,testMatrix)

	return(result)
}

ComputeVariables<-function(vars,regclass,target,explain=13){


	user_id<-unique(vars[,1])
	du<-sort(unique(vars[,4]))

	regdate<-regclass[regclass[,1]==user_id,2]
	if(length(regdate)!=0){
		if(regdate>du[1]){
			regdate<-head(du,1)
		}
	}else{
		regdate<-head(du,1)
	}

	#compute revisions,articles
	period<-factor(vars[,4])
	nrevisions<-tapply(vars[,2],period,length)

	#compute delta rate
	deltarate<-tapply(ifelse(vars[,5]==0,0,ifelse(vars[,5]>0,vars[,5]/vars[,6],abs(vars[,5])/(vars[,6]-vars[,5]))),period,sum)
	
	#cbind
	dateclass<-cbind(du,nrevisions,deltarate)

	#complete.vars
	dateclass<-complete.vars(dateclass,start=regdate,end=target)
	if(is.null(dim(dateclass))){
		dim(dateclass)<-c(1,length(dateclass))
	}

	#names
	rownames(dateclass)<-NULL
	colnames(dateclass)<-c("DateClass","Revisions","DeltaRate")

	#out of dates
	outdates<-setdiff(seq(target-explain,target-1),dateclass[,1])
	outdatesvalue<-rep(0,length(outdates))

	#delete target date data
	whichtarget<-which(vars[,4]>=target)
	if(length(whichtarget)!=0){
		vars<-vars[-whichtarget,]
		if(is.null(dim(vars))){
			vars<-t(as.matrix(vars))
		}
	}
	
	#true article num
	articles<-length(unique(vars[,2]))
	revisions<-length(vars[,2])


	#compute deltaratesum
	deltarate<-dateclass[which(dateclass[,1]==c(target-1)),3]
	if(length(deltarate)==0){deltarate<-0}
	delta<-sum(vars[which(vars[,4]==c(target-1)),5])

	deltaratesum<-sum(dateclass[which(dateclass[,1]<target),3])
	deltaplusrate<-sum(ifelse(vars[,5]>=0,1,0)/length(vars[,5]))
	deltamean<-ifelse(is.nan(mean(vars[,5])),0,mean(vars[,5]))
	sumdelta<-sum(abs(vars[,5]))
	deltavec<-c(deltamean,deltaplusrate,deltaratesum,deltarate,delta)
	deltaveclabel<-c("MeanDelta","PlusDeltaRate","DeltaRateSum","LastDeltaRate","LastDelta")


	#namespace rate
	namespaces<-factor(vars[,3])
	namerate<-tapply(abs(vars[,5]),namespaces,function(x){sum(x)/sumdelta})
	namerate<-cbind(as.integer(levels(namespaces)),namerate)
	for(i in c(0:5)){
		if(!any(namerate[,1]==i)){
			namerate<-rbind(namerate,c(i,0))
		}
	}
	namerate<-namerate[order(namerate[,1]),2]
	namerate<-ifelse(is.nan(namerate),0,namerate)
	nameratelabel<-c("namespace0","namespace1","namespace2","namespace3","namespace4","namespace5")

	#reverted 
	revertedvec<-vars[,8]
	revertmyself<-length(which(revertedvec==user_id))
	revertother<-length(which(revertedvec!=user_id))-length(which(revertedvec==-1))
	nreverted<-c(revertmyself,revertother)
	revertlabel<-c("RevertedByMyself","RevertedByOthers")

	#category num
	categoryvec<-vars[,9]
	nmediation<-length(which(categoryvec==1))+length(which(categoryvec==2))+length(which(categoryvec==3))
	nfuture<-length(which(categoryvec==3))+length(which(categoryvec==4))+length(which(categoryvec==6))+length(which(categoryvec==7))+length(which(categoryvec==8))+length(which(categoryvec==9))+length(which(categoryvec==10))

	ncategory<-c(nmediation,nfuture)
	categorylabel<-c("CProcedural","CEvaluative")


	#redirect num
	nredirect<-sum(na.omit(vars[,10]))

	#related_page num
	nrelated<-length(na.omit(which(vars[,11]!=-1)))

	#Increase Decrease
	revisionvec<-c(0,dateclass[which(dateclass[,1]<target),2])
	periodvec<-dateclass[which(dateclass[,1]<target),1]
	diffvec<-diff(revisionvec)
	if(length(diffvec)==0){diffvec<-c(0)}
	incrate<-length(which(diffvec>0))/c(target-1)
	weightedinc<-sum((100/(target-periodvec[which(diffvec>0)]))*diffvec[which(diffvec>0)])
	weighteddec<-abs(sum((100/(target-periodvec[which(diffvec<0)]))*diffvec[which(diffvec<0)]))
	maxinc <-max(diffvec[which(diffvec>=0)])
	maxdec <-ifelse(length(which(diffvec<0))==0,0,min(diffvec[which(diffvec<0)]))
	lastdiff<-tail(diffvec,1)
	incvec<-c(incrate,weightedinc,weighteddec,maxinc,maxdec,lastdiff)
	incveclabel<-c("IncRate","WeightedInc","WeightedDec","MaxInc","MaxDec","LastDiff")

	#character length
	titlelength<-unique(vars[,c(2,12)])
	titlelength<-cbind("period_id"=vars[c(as.integer(rownames(titlelength))),4],titlelength)
	nchartitle<-tapply(titlelength[,3],as.factor(titlelength[,1]),function(x){sum(na.omit(x))})
	if(length(nchartitle)==0){nchartitle<-0}
	nchartitlemean<-mean(nchartitle)

	ncharcomment<-tapply(vars[,13],as.factor(vars[,4]),function(x){sum(na.omit(x))})
	if(length(ncharcomment)==0){ncharcomment<-0}
	ncharcommentmean<-mean(ncharcomment)
	ncharcommentmax<-max(ncharcomment)
	ncharcommentmin<-min(ncharcomment)
	ncharcommentlast<-tail(ncharcomment,1)
	nchar<-c(nchartitlemean,ncharcommentmean,ncharcommentmax,ncharcommentmin,ncharcommentlast)
	ncharlabel<-c("nCharTitleMean","CommentMean","CommentMax","CommentMin","LastComment")
	
	#Revisions
	ntarget<-dateclass[which(dateclass[,1]==target),2]
	nexplain<-c(outdatesvalue,dateclass[which(dateclass[,1]<target),2])
	nexplain<-tail(nexplain,explain)

	#Period
	periodnum<-length(dateclass[which(dateclass[,1]<target),2])
	activenum<-length(which(du<target))
	nexplainlabel<-paste("nExplain",seq(1,explain),sep="")

	#Get Vector of target
	vec<-c(user_id,revisions,articles,namerate,deltavec,nreverted,ncategory,nredirect,nrelated,incvec,nchar,periodnum,activenum,nexplain,ntarget)
	dim(vec)<-c(1,length(vec))
	colnames(vec)<-c("userID","nRevision","nArticle",nameratelabel,deltaveclabel,revertlabel,categorylabel,"nRedirect","nRelated",incveclabel,ncharlabel,"Period","ActivePeriod",nexplainlabel,"nTarget")

	return(vec)
}


complete.vars<-function(x,start=1,end=23){
	duration<-seq(start,end)
	comp<-x

	for(i in duration){
		if(!any(comp[,1]==i)){
			comp<-rbind(comp,c(i,rep(0,ncol(comp)-1)))
		}
	}
	comp<-comp[order(comp[,1]),]
	return(comp)
}

nonPredict<-function(varslists){
	
	colnamevec<-colnames(varslists)
	col<-which(colnamevec=="ActivePeriod")
	if(varslists[1,col]==0){
		vec<-0
	}else{
		vec<-1
	}
	return(vec)
}
	
ModelConstruction <- function(trainMatrix) {

	#Log
	logvec<-c(2,3,c(34:47))
	trainMatrix[,logvec]<-log(abs(trainMatrix[,logvec])+1)

	#as double regression
	trainMatrix<-data.frame(trainMatrix[,-1])
	
	#plsr model construction
	library(pls)
	set.seed(20)

	fm<-as.formula(paste(colnames(trainMatrix)[ncol(trainMatrix)],"~.",sep=""))	

	result <- plsr(fm,data=trainMatrix,scale=T,validation="CV",method="kernelpls")

	return(result)
}
PredictionSubmission<-function(testMatrix,result,ncomp){

	logvec<-c(2,3,c(34:47))
	testMatrix[,logvec]<-log(abs(testMatrix[,logvec])+1)

	userid<-testMatrix[,1]
	#as double regression
	testMatrix<-data.frame(testMatrix[,-1])

	prediction<-predict(result,newdata=testMatrix,type=c("response"),ncomp=ncomp)
	
	if(length(which(prediction<0))!=0){prediction<-ifelse(prediction<0,0,prediction)}
	if(length(which(is.na(prediction)))!=0){prediction<-ifelse(is.na(prediction),0,prediction)}
	prediction<-exp(prediction)-1

	solution<-cbind("user_id"=userid,"solution"=prediction)

	return(solution)
}



