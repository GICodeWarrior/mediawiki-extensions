#R source code
#execute below functions

setwd("")               #source code derectory
password<-""   	   #MySQL password
source("R_source_code_functions.R")

Matrix<-getMatrix(password)
result<-ModelConstruction(Matrix[[1]])
summary(result,what="validation")
n<-13
solution<-PredictionSubmission(Matrix[[2]],result,n)
write.csv(solution,file="solution.csv",quote=F,row.names=F)

