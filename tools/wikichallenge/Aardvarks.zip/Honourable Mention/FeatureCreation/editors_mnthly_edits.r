rm(list = ls())
setwd("D:/ICDM11");
NE = 44514
t0 = strptime("2001-01-01 0:0:0", "%Y-%m-%d %H:%M:%S"); 
te = strptime("2010-09-01 0:0:0", "%Y-%m-%d %H:%M:%S"); 
NM = 116
Mlen = (te-t0)/NM

A <- scan('edit_times.csv','character');
stopifnot(length(A) == NE)

MatAll <- array(0,c(NE,NM))
MatUnq <- array(0,c(NE,NM))

for (ia in 1:NE){

	if (ia%%2000 == 0) {cat(sprintf("Parsed %i of %i editors",ia,NE),"\n")}

	splita <- as.integer(strsplit(A[ia],",",fixed=T)[[1]])
	for (m in 1:NM){
		winst = (m-1)*Mlen
		winen = winst + Mlen
		iwithin = (splita > winst & splita <= winen)
		MatAll[ia,m] = sum(iwithin)
		MatUnq[ia,m] = length(unique(splita[iwithin]))
	}
}
cat(sprintf("Writing tables into CSV files..."),"\n")
write(t(MatAll),'editor_monthly_edits.csv',ncolumns = dim(MatAll)[2],sep = ",")
write(t(MatUnq),'editor_monthly_edits_unique_days.csv',ncolumns = dim(MatUnq)[2],sep = ",")
alarm()


RD <- read.csv('E:/public/ICDM11/wikichallenge_data_all/regdates.tsv',header=T,sep='\t')
EL <- scan('editor_list.txt',what='integer')
EL = as.integer(EL)
ELT = array(0,c(length(EL),2))
t0 = strptime("2001-01-01 0:0:0", "%Y-%m-%d %H:%M:%S"); 

for (i in 1:length(EL)){
	ix <- which(RD[,1] == EL[i])
	ELT[i,2] <- strptime(RD[ix,2],"%Y-%m-%d") - t0
}
ibad = which(is.na(ELT[,2]))
for (ib in ibad){
	ELT[ib,2] <- min(as.integer(strsplit(A[ib],',',fixed=T)[[1]]))
}
write(t(ELT),file='editor_regdate.csv',sep=',',ncolumns=2)


