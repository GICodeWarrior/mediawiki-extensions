#source('D:/ICDM11/mygit/Kalpit/editors_mnthly_edits.r')
rm(list = ls())
setwd("D:/ICDM11");
NE = 44514
t0 = strptime("2001-01-01 0:0:0", "%Y-%m-%d %H:%M:%S"); 
te = strptime("2010-09-01 0:0:0", "%Y-%m-%d %H:%M:%S"); 
NM = 116
Mlen = as.numeric((te-t0)/NM)

A <- scan('edit_times_unrounded.csv','character');
stopifnot(length(A) == NE)

MatAll <- matrix(0,NE,NM+1)
MatUnq <- matrix(0,NE,NM+1)
fsdt = read.csv("Editor_FSDTnum.csv", header = TRUE);

for (ia in 1:NE){

	if (ia%%2000 == 0) {cat(sprintf("Parsed %i of %i editors",ia,NE),"\n")}

	MatAll[ia,1] = fsdt[ia,1]
	MatUnq[ia,1] = fsdt[ia,1]
	
	splita <- as.numeric(strsplit(A[ia],",",fixed=T)[[1]])
	for (m in 1:NM){
		winst = (m-1)*Mlen
		winen = winst + Mlen
		iwithin = (splita > winst & splita <= winen)
		MatAll[ia,m+1] = sum(iwithin)
		if (MatAll[ia,m+1] > 0){
			MatUnq[ia,m+1] = sum(diff(sort(splita[iwithin])) > 0.5) + 1
		}
	}
}
cat(sprintf("Writing tables into CSV files..."),"\n")
colnames(MatAll) = c("user_id",seq(1,NM,1));
colnames(MatUnq) = c("user_id",seq(1,NM,1));

write(t(MatAll),'editor_monthly_edits_unrounded.csv',ncolumns = dim(MatAll)[2],sep = ",")
write(t(MatUnq),'editor_monthly_edits_unique_sessions_unrounded.csv',ncolumns = dim(MatUnq)[2],sep = ",")
alarm()


# RD <- read.csv('E:/public/ICDM11/wikichallenge_data_all/regdates.tsv',header=T,sep='\t')
# EL <- scan('editor_list.txt',what='integer')
# EL = as.integer(EL)
# ELT = array(0,c(length(EL),2))
# t0 = strptime("2001-01-01 0:0:0", "%Y-%m-%d %H:%M:%S"); 

# for (i in 1:length(EL)){
	# ix <- which(RD[,1] == EL[i])
	# ELT[i,2] <- strptime(RD[ix,2],"%Y-%m-%d") - t0
# }
# ibad = which(is.na(ELT[,2]))
# for (ib in ibad){
	# ELT[ib,2] <- min(as.integer(strsplit(A[ib],',',fixed=T)[[1]]))
# }
# write(t(ELT),file='editor_regdate.csv',sep=',',ncolumns=2)


