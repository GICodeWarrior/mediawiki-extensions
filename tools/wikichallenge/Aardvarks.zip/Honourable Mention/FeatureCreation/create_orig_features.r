#source('D:\\ICDM11\\mygit\\Kalpit\\FeatureCreation\\create_orig_features.r')
rm(list =ls())

# Run eid_time_table_unrounded.py and then eid_fsdt_regdate_table_creation.r before running this script

# Raw Input Files:
# Derived Input files:
#   'OrigSubset1_Lead.csv'
#   'OrigSubset1_Train.csv'
#   'Parsed_RawDump_Full.csv'

NE = 44514
NT = 22126031
rootdir = 'E:\\public\\ICDM11\\wikichallenge_data_all\\'
resdir = 'D:\\ICDM11\\'
input_file = paste(rootdir,'training.tsv',sep='')

t0 = strptime("2001-01-01 0:0:0", "%Y-%m-%d %H:%M:%S"); 
te.lead = as.numeric(strptime("2010-09-01 0:0:0", "%Y-%m-%d %H:%M:%S") - t0); 
te.train = as.numeric(strptime("2010-04-01 0:0:0", "%Y-%m-%d %H:%M:%S") - t0);
tl5.lead = te.train
tl5.train = as.numeric(strptime("2009-11-01 0:0:0", "%Y-%m-%d %H:%M:%S") - t0);

ResMatLead = read.csv("OrigSubset1_Lead.csv", header=T); ResMatLead[ResMatLead==-1] = 0
ResMatTrain = read.csv("OrigSubset1_Train.csv", header=T); ResMatTrain[ResMatTrain==-1] = 0


# if (!("A" %in% ls())){
	# #A = readLines(input_file,n=-1) ## requires aprx 4 GB RAM
	# load('Full_training_tsv.rdata')
# }
# stopifnot(length(A) == NT+1) #Topline is the header file
A = read.csv('Parsed_RawDump_Full.csv',header=T)

# Create Name space variable-name list
var_sum_edit = list()
var_sum_reverts = list()
var_sum_edit_l5 = list()
var_sum_reverts_l5 = list()
for (nspace in 0:5){
	var_sum_edit[nspace+1] = paste('sum_edit_ns',nspace,sep='')
	var_sum_reverts[nspace+1] = paste('sum_reverts_ns',nspace,sep='')
	
	var_sum_edit_l5[nspace+1] = paste(var_sum_edit[nspace+1],'_l5',sep='')
	var_sum_reverts_l5[nspace+1] = paste(var_sum_reverts[nspace+1],'_l5',sep='')
}
var_sum_edit = unlist(var_sum_edit);
var_sum_edit_l5 = unlist(var_sum_edit_l5);
var_sum_reverts = unlist(var_sum_reverts);
var_sum_reverts_l5 = unlist(var_sum_reverts_l5);
# THe huge loop
artlist = rep(list(NA),NE)
artlist.train = rep(list(NA),NE)
for (i in 2:NT+1){
	if (i%%200000 == 0) {cat(sprintf("Parsed %i of %i lines",i,NE),"\n"); flush.console();}
	#sline = strsplit(A[i],'\t')[[1]]	
	
	# uid = as.integer(sline[i.uid])
	# artid = as.integer(sline[i.artid])
	# nspace = as.integer(sline[i.ns]) #namespace
	# tstamp = as.numeric(strptime(sline[i.tstamp], "%Y-%m-%d %H:%M:%S") - t0);
	# revflag = as.integer(sline[i.revflag])
	# revuid = as.integer(sline[i.revuid])
	# delta = as.integer(sline[i.delta])
	uid = A[i,1]
	artid = A[i,2]
	nspace = A[i,3]
	tstamp = A[i,4]
	revflag = A[i,5]
	revuid = A[i,6]
	delta = A[i,7]
	#--------------------------------------------
	ilead = which(ResMatLead$user_id == uid)		
	itrain = which(ResMatTrain$user_id == uid)
	user.in.training = (length(itrain) > 0)	
	edit.in.leadl5 = (tstamp >= tl5.lead)
	edit.in.trainl5 = ((tstamp >= tl5.train) && (tstamp < te.train))
	
	#---------- LEADERBOARD ---------------------
	ResMatLead[ilead,var_sum_edit[nspace+1]] = ResMatLead[ilead,var_sum_edit[nspace+1]] + 1
	if(edit.in.leadl5){
		ResMatLead[ilead,var_sum_edit_l5[nspace+1]] = ResMatLead[ilead,var_sum_edit_l5[nspace+1]] + 1
	}
	if(revflag==1){
		ResMatLead$sum_reverts[ilead] = ResMatLead$sum_reverts[ilead] + 1
		ResMatLead[ilead,var_sum_reverts[nspace+1]] = ResMatLead[ilead,var_sum_reverts[nspace+1]] + 1
		if(edit.in.leadl5){
			ResMatLead$sum_reverts_l5[ilead] = ResMatLead$sum_reverts_l5[ilead] + 1
			ResMatLead[ilead,var_sum_reverts_l5[nspace+1]] = ResMatLead[ilead,var_sum_reverts_l5[nspace+1]] + 1
		}
		
		irevid = which(ResMatLead$user_id == revuid)
		if (length(irevid) > 0){ 
			ResMatLead$sum_reverts_self[irevid] = ResMatLead$sum_reverts_self[irevid] + 1
			if(edit.in.leadl5){
				ResMatLead$sum_reverts_self_l5[irevid] = ResMatLead$sum_reverts_self_l5[irevid] + 1
			}
		}
	}
	
	if (!(artid %in% artlist[[ilead]])){
		ResMatLead$sum_articles[ilead] = ResMatLead$sum_articles[ilead]+1		
		if(edit.in.leadl5){
			ResMatLead$sum_new_articles_l5[ilead] = ResMatLead$sum_new_articles_l5[ilead]+1
		}
		artlist[[ilead]] = c(artlist[[ilead]],artid)		
	}
	
	ResMatLead$sum_delta[ilead] = ResMatLead$sum_delta[ilead] + delta
	if(edit.in.leadl5){
		ResMatLead$sum_delta_l5[ilead] = ResMatLead$sum_delta_l5[ilead] + delta
	}
	
	#---------- TRAINING ---------------------
	if(user.in.training && tstamp < te.train){
		ResMatTrain[itrain,var_sum_edit[nspace+1]] = ResMatTrain[itrain,var_sum_edit[nspace+1]] + 1
		if(edit.in.trainl5){
			ResMatTrain[itrain,var_sum_edit_l5[nspace+1]] = ResMatTrain[itrain,var_sum_edit_l5[nspace+1]] + 1
		}
		if(revflag==1){
			ResMatTrain$sum_reverts[itrain] = ResMatTrain$sum_reverts[itrain] + 1
			ResMatTrain[itrain,var_sum_reverts[nspace+1]] = ResMatTrain[itrain,var_sum_reverts[nspace+1]] + 1
			if(edit.in.trainl5){
				ResMatTrain$sum_reverts_l5[itrain] = ResMatTrain$sum_reverts_l5[itrain] + 1
				ResMatTrain[itrain,var_sum_reverts_l5[nspace+1]] = ResMatTrain[itrain,var_sum_reverts_l5[nspace+1]] + 1
			}
			
			irevid = which(ResMatTrain$user_id == revuid)
			if (length(irevid) > 0){ 
				ResMatTrain$sum_reverts_self[irevid] = ResMatTrain$sum_reverts_self[irevid] + 1
				if(edit.in.trainl5){
					ResMatTrain$sum_reverts_self_l5[irevid] = ResMatTrain$sum_reverts_self_l5[irevid] + 1
				}
			}
		}
		
		if (!(artid %in% artlist.train[[itrain]])){
			ResMatTrain$sum_articles[itrain] = ResMatTrain$sum_articles[itrain]+1		
			if(edit.in.trainl5){
				ResMatTrain$sum_new_articles_l5[itrain] = ResMatTrain$sum_new_articles_l5[itrain]+1
			}
			artlist.train[[itrain]] = c(artlist.train[[itrain]],artid)		
		}
		
		ResMatTrain$sum_delta[itrain] = ResMatTrain$sum_delta[itrain] + delta
		if(edit.in.trainl5){
			ResMatTrain$sum_delta_l5[itrain] = ResMatTrain$sum_delta_l5[itrain] + delta
		}	
	}
}

ResMatTrain$y_next5_edits = ResMatLead[which(ResMatLead$user_id %in% ResMatTrain$user_id),'sum_edits_l5']

write.csv(ResMatLead, file = "OrigSet_xinp1p2p3.csv", row.names = FALSE);
write.csv(ResMatTrain, file = "OrigSet_xinp1p2_yinp3.csv", row.names = FALSE);

# JT = read.csv('D:/ICDM11/SASoutput/FEATURES/features_xinp1p2_yinp3_29Jul.csv',header=T)
# JL = read.csv('D:/ICDM11/SASoutput/FEATURES/features_xinp1p2p3_29Jul.csv',header=T)

#/ Column	Explanation
#/ user_id	user-id
#/ FSDT	The First timestamp that this user made an edit on
#/ LSDT	The last timestamp (before 31-Oct-2009 midnight) that this  user made an edit
#/ registration_date	The date that the user registered on
#/ sum_edits	Total number of edits that the user made (as on p1 end)
#/ sum_edit_days	Total number of days  that the user made edits on (as on p1 end)
#[ sum_edit_ns0	Total number of edits that this user made (as on p1 end) in the namespace category 0
#[ sum_edit_ns1	Total number of edits that this user made (as on p1 end) in the namespace category 1
#[ sum_edit_ns2	Total number of edits that this user made (as on p1 end) in the namespace category 2
#[ sum_edit_ns3	Total number of edits that this user made (as on p1 end) in the namespace category 3
#[ sum_edit_ns4	Total number of edits that this user made (as on p1 end) in the namespace category 4
#[ sum_edit_ns5	Total number of edits that this user made (as on p1 end) in the namespace category 5
#[ sum_reverts	Total number of reverts that the user had (as on p1 end)
#[ sum_reverts_ns0	Total number of reverts (as on p1 end)  for edits of namespace 0
#[ sum_reverts_ns1	Total number of reverts (as on p1 end)  for edits of namespace 1
#[ sum_reverts_ns2	Total number of reverts (as on p1 end)  for edits of namespace 2
#[ sum_reverts_ns3	Total number of reverts (as on p1 end)  for edits of namespace 3
#[ sum_reverts_ns4	Total number of reverts (as on p1 end)  for edits of namespace 4
#[ sum_reverts_ns5	Total number of reverts (as on p1 end)  for edits of namespace 5
#[ sum_reverts_self	Total number of reverts (as on p1 end) that the user  himself/herself made
# sum_articles	Total number of  unique articles edited by the user (as on p1 end)
# sum_delta	sum of all the deltas of edits madeby the user (as of p1 end)
#/ sum_edits_l5	Total number of edits that the user made (in the last 5 month before p1 ended)
#/ sum_edit_days_l5	Total number of days  that the user made edits on (in the last 5 months before p1 ended)
#[ sum_edit_ns0_l5	Total number of edits that this user made (in the last 5 months before p1 ended) in the namespace category 0
#[ sum_edit_ns1_l5	Total number of edits that this user made (in the last 5 months before p1 ended) in the namespace category 1
#[ sum_edit_ns2_l5	Total number of edits that this user made (in the last 5 months before p1 ended) in the namespace category 2
#[ sum_edit_ns3_l5	Total number of edits that this user made (in the last 5 months before p1 ended) in the namespace category 3
#[ sum_edit_ns4_l5	Total number of edits that this user made (in the last 5 months before p1 ended) in the namespace category 4
#[ sum_edit_ns5_l5	Total number of edits that this user made (in the last 5 months before p1 ended) in the namespace category 5
#[ sum_reverts_l5	Total number of reverts that the user had (in the last 5 months before p1 ended)
#[ sum_reverts_ns0_l5	Total number of reverts (in the last 5 months before p1 ended)  for edits of namespace 0
#[ sum_reverts_ns1_l5	Total number of reverts (in the last 5 months before p1 ended)  for edits of namespace 1
#[ sum_reverts_ns2_l5	Total number of reverts (in the last 5 months before p1 ended)  for edits of namespace 2
#[ sum_reverts_ns3_l5	Total number of reverts (in the last 5 months before p1 ended)  for edits of namespace 3
#[ sum_reverts_ns4_l5	Total number of reverts (in the last 5 months before p1 ended)  for edits of namespace 4
#[ sum_reverts_ns5_l5	Total number of reverts (in the last 5 months before p1 ended)  for edits of namespace 5
#[ sum_reverts_self_l5	Total number of reverts (in the last 5 months before p1 ended) that the user  himself/herself made
# sum_new_articles_l5	Total number of articles that the user edited for the first tiem in the last 5 months before p1 ended
# sum_delta_l5	sum of all the deltas of edits madeby the user (in the last 5 months before p1 ended)
#/ Edits_mth_cutoff_minus_4	Number of edits 4 months before the last month of p1 (i.e., Jun-09)
#/ Edits_mth_cutoff_minus_3	Number of edits 3 months before the last month of p1 (i.e., Jul-09)
#/ Edits_mth_cutoff_minus_2	Number of edits 2 months before the last month of p1 (i.e., Aug-09)
#/ Edits_mth_cutoff_minus_1	Number of edits 1 month before the last month of p1 (i.e., Sep-09)
#/ Edits_mth_cutoff_minus_0	Number of edits 0 months before the last month of p1 (i.e., in the month of Oct-09)
# y_next5_edits	Number of edits that the user made in the 5 months post p1 (Nov-09to Mar-10)
