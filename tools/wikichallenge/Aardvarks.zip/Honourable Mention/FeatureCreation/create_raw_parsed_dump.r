NT = 22126031
rootdir = 'E:\\public\\ICDM11\\wikichallenge_data_all\\'
input_file = paste(rootdir,'training.tsv',sep='')

t0 = strptime("2001-01-01 0:0:0", "%Y-%m-%d %H:%M:%S"); 

con <- file(input_file,'r')
open(con); readLines(con,n=1); #read the header

rawParser <- function(i){
	#sline = strsplit(A[i],'\t')[[1]]
	rline = readLines(con, n=1)
	sline = strsplit(rline,'\t')[[1]]
	
	pA = rep(0,7)
	pA[1] = as.integer(sline[1])
	pA[2] = as.integer(sline[2])
	pA[3] = as.integer(sline[4]) #namespace
	pA[4] = as.numeric(strptime(sline[5], "%Y-%m-%d %H:%M:%S") - t0);
	pA[5] = as.integer(sline[7])
	pA[6] = as.integer(sline[8])
	pA[7] = as.integer(sline[10])
	if (i%%200000 == 0) {cat(sprintf("Parsed %i of %i lines",i,NT),"\n"); flush.console();}
	return(pA)
}

parsedA = t(sapply(2:(NT+1),rawParser,simplify='matrix'))
save(parsedA,file='Parsed_RawDump_Full.rdata')
colnames(parsedA) = c('uid','article.id','namespace','timestamp','revert.flag','revert.uid','delta')
write.csv(parsedA,file='Parsed_RawDump_Full.csv',row.names=F)

close(con)
